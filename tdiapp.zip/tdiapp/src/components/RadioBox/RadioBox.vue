<template>
  <div class="radio-box">
    <h5>Katigoriyalar</h5>
    <hr />
    <div class="radio-inner">
      <b-form-radio name="radio-size" size="sm">Small</b-form-radio>
      <p>77</p>
    </div>
    <div class="radio-inner">
      <b-form-radio name="radio-size" size="sm">Small</b-form-radio>
      <p>77</p>
    </div>
    <div class="radio-inner">
      <b-form-radio name="radio-size" size="sm">Small</b-form-radio>
      <p>77</p>
    </div>
    <div class="radio-inner">
      <b-form-radio name="radio-size" size="sm">Small</b-form-radio>
      <p>77</p>
    </div>
  </div>
</template>

<script>
export default {
  name: "RadioBox",
};
</script>

<style lang="scss" scoped>
@import "RadioBox";
</style>
