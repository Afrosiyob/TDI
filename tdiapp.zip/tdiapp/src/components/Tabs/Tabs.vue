<template>
  <div>
    <b-tabs content-class="mt-3">
      <b-tab title="First" active>
        <h3>This is Firsdt titul</h3>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo iusto
          illum accusantium enim nam quas eius ab itaque est laudantium ea
          tempora suscipit, dolorum perspiciatis quod, vero optio corporis
          aliquam.
        </p></b-tab
      >
      <b-tab title="Second"
        ><h3>This is Second titul</h3>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo iusto
          illum accusantium enim nam quas eius ab itaque est laudantium ea
          tempora suscipit, dolorum perspiciatis quod, vero optio corporis
          aliquam.
        </p></b-tab
      >
      <b-tab title="Disabled"
        ><h3>This is Three titul</h3>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo iusto
          illum accusantium enim nam quas eius ab itaque est laudantium ea
          tempora suscipit, dolorum perspiciatis quod, vero optio corporis
          aliquam.
        </p></b-tab
      >
    </b-tabs>
  </div>
</template>

<script>
export default {
  name: "Tabs",
};
</script>

<style lang="scss" scoped>
@import "Tabs";
</style>
