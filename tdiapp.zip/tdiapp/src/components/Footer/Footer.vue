<template>
  <div class="footer-box">
    <b-container>
      <p>Copyright © 2010-2020 . All rights reserved.</p>
      <p>Create by: ESE Group</p>
    </b-container>
  </div>
</template>

<script>
export default {
  name: "Footer",
};
</script>

<style lang="scss" scoped>
@import "Footer";
</style>
